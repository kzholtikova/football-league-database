create
    definer = root@`%` procedure teams_by_season(INOUT current_season text, INOUT teams_num int)
BEGIN
    SET @season_id = 0;
    SELECT s.name, s.id INTO current_season, @season_id
    FROM seasons s
    ORDER BY s.start_date DESC
    LIMIT 1;
    
    SELECT COUNT(DISTINCT a.team_id) INTO teams_num
    FROM attendees a
        JOIN matches m on m.id = a.match_id
        JOIN match_days md on md.id = m.match_day_id
    WHERE md.season_id = @season_id; 
END;

